/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "usbd_cdc_if.h"
#include "usbd_cdc.h"
extern uint8_t CDC_Transmit_FS(uint8_t* Buf, uint16_t Len);
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

TIM_HandleTypeDef htim5;
TIM_HandleTypeDef htim6;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MPU_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM6_Init(void);
static void MX_TIM5_Init(void);
/* USER CODE BEGIN PFP */
extern USBD_HandleTypeDef hUsbDeviceFS;
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

#define MAX_TXRX_DATA 20000
uint32_t buf_M_RX[MAX_TXRX_DATA + 1];//+4bytes for head
uint32_t buf_M_TX[MAX_TXRX_DATA + 1];
uint32_t m2s_buf[MAX_TXRX_DATA];//
int s2m_Status;// transmit to Matlab
int m2s_Status;// received status 0...waiting for incomming data, 1...call m2s_Process, -1... init receiving, 2...n data , 3... xData
int m2s_ID;
int m2s_nData_in_bytes;

uint32_t start_time, end_time, elapsed_time; //zmerime cas

/*char sendData[12] = "Hello World!";
uint8_t rxBuffer[1024];
volatile uint32_t rxLength = 0;
volatile uint8_t rxComplete = 0;
uint32_t sumOfData = 0;*/

int DataTransmit2MTLB(uint16_t iD, uint8_t * xData, uint16_t nData_in_values, uint32_t elapsed_time)
{
	if(s2m_Status) return -1;
	if((sizeof(buf_M_TX)-4)<((nData_in_values+1)*4)) return -2;
	s2m_Status=1;
	((uint16_t *) buf_M_TX)[0] = iD;
	((uint16_t *) buf_M_TX)[1] = nData_in_values + 1; // +1 - prvek casu

	if(nData_in_values>0) memcpy(buf_M_TX+1, xData, nData_in_values*4);

	 float elapsed_time_float = (float)elapsed_time;
	 memcpy(buf_M_TX + 1 + nData_in_values, &elapsed_time_float, sizeof(float));

	s2m_Status = CDC_Transmit_FS((uint8_t*) buf_M_TX, (nData_in_values+1)*4 + 4);
	if(s2m_Status){
		s2m_Status=0;//if on zero... USB busy
	}

	return 0;
}



void DataReceive_MTLB_Callback(uint16_t iD, uint32_t * xData, uint16_t nData_in_values, uint32_t elapsed_time)
{//kdyz prijdou data z matlabu, tak se toto zavola a zde je vetveni a zpracovani

	switch(iD)
	{
		case 40001:
			char t[12]="Hello world!";
			uint32_t t32[12];
			for(int i=0; i<12; i++)
				t32[i]= t[i];
				//odeslani
			DataTransmit2MTLB(40001,(uint8_t *) &t32[0], 12, elapsed_time);
			break;
		case 40002:
			DataTransmit2MTLB(40002, (uint8_t *)xData, nData_in_values, elapsed_time);
			break;
		case 50002:
			DataTransmit2MTLB(50002, (uint8_t *)xData, nData_in_values, elapsed_time);
			break;
		default:
			break;
	}
}

int t;

void m2s_Process(void)//called from inf. loop
{
	if(!m2s_Status) return;		//pokud neprijde, tak ignorovat

	if(m2s_Status==1){
		end_time = TIM5->CNT;

		 // Calculate elapsed time
		 if (end_time >= start_time) {
		      elapsed_time = end_time - start_time;  // Normální případ
		 } else {
		       elapsed_time = (0xFFFF - start_time) + end_time + 1;  // Ošetření přetečení
		 }
		 // Process data (this will now include elapsed time in the response)
		 DataReceive_MTLB_Callback(m2s_ID, m2s_buf, m2s_nData_in_bytes/4, elapsed_time);
		 t++;
		 m2s_Status = 0;
		 return;
	}
	if(m2s_Status== -1){//init receiving new message from matlab
		m2s_Status = 0;
		return;
	}

}

uint32_t y[2] = {1010, 1};

void sendDataToMatlab() {
	y[1]++;
    HAL_StatusTypeDef status = CDC_Transmit_FS((uint8_t *) y, 8);
    while (status == USBD_BUSY) {     //resit
    	status = CDC_Transmit_FS((uint8_t *) y, 8);
    }

    if (status == HAL_OK) {
        printf("Data sent successfully.\n");
    } else {
        printf("Failed to send data.\n");
    }
}



void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
    if (GPIO_Pin == S1_Pin) {
        HAL_GPIO_WritePin(LD7_GPIO_Port, LD7_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(LD8_GPIO_Port, LD8_Pin, GPIO_PIN_RESET);
        sendDataToMatlab();
    }
}


uint32_t x1;
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* Prevent unused argument(s) compilation warning */
  if(htim== &htim6)
  {
	if(x1>0)
		DataTransmit2MTLB(1010, (uint8_t *) &x1, 1, 0);
		x1++;
		HAL_GPIO_TogglePin(LD1_GPIO_Port, LD1_Pin);
  }

}


void USB_My_Receive(uint8_t* Buf, uint32_t Len) {
    static uint32_t rxIndex = 0;  // Index do přijímacího bufferu

    if (m2s_Status == 0) { // Nová zpráva
        m2s_ID = ((uint16_t*) Buf)[0];
        if (m2s_ID == 0) return;

        m2s_Status = 100;  // Očekáváme další část dat
        rxIndex = 0;       // Reset indexu
        return;
    }

    if (m2s_Status == 100) { // Přišel údaj o délce zprávy
        m2s_nData_in_bytes = ((uint16_t*) Buf)[0] * 4; // Počet bajtů
        start_time = TIM5->CNT;   // Uložíme čas začátku

        if (m2s_nData_in_bytes == 0) {
            m2s_Status = 1;  // Není žádná data, rovnou zpracujeme
            //DataReceive_MTLB_Callback(m2s_ID, NULL, 0);
            return;
        }
        m2s_Status = 3;  // Čekáme na hlavní data
        rxIndex = 0;
        return;
    }

    if (m2s_Status == 3) { // Přicházejí hlavní data
        if (rxIndex + Len > MAX_TXRX_DATA * 4) {
            // Ochrana proti přetečení
            m2s_Status = 0;
            return;
        }
        // Kopírování dat do bufferu
        memcpy((uint8_t*)m2s_buf + rxIndex, Buf, Len);
        rxIndex += Len;
        // Pokud jsme přijali všechna očekávaná data
        if (rxIndex >= m2s_nData_in_bytes) {
            //DataReceive_MTLB_Callback(m2s_ID, m2s_buf, m2s_nData_in_bytes / 4);
            m2s_Status = 1;  //Stav zpracovani v m2s_process
        }
        return;
    }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MPU Configuration--------------------------------------------------------*/
  MPU_Config();

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USB_DEVICE_Init();
  MX_TIM6_Init();
  MX_TIM5_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start(&htim5);
  HAL_TIM_Base_Start_IT(&htim6);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  m2s_Process();
	  /*if (rxComplete) {
	          rxComplete = 0; // Reset příznaku

	          // Parsování dat: nejdříve ID a délka
	          uint16_t receivedID = (rxBuffer[0] << 8) | rxBuffer[1];
	          uint16_t receivedLength = (rxBuffer[2] << 8) | rxBuffer[3];

	          if (receivedLength > 0 && receivedLength < sizeof(rxBuffer) - 4) {
	              char receivedString[receivedLength + 1];
	              memcpy(receivedString, &rxBuffer[4], receivedLength);
	              receivedString[receivedLength] = '\0'; // Přidání ukončovacího znaku

	              printf("Přijato ID: %d, Data: %s\n", receivedID, receivedString);
	          }
	      }*/

	  /*HAL_GPIO_TogglePin(LD1_GPIO_Port, LD1_Pin);
	  HAL_Delay(500);
	  HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
	  HAL_Delay(500);
	  HAL_GPIO_TogglePin(LD3_GPIO_Port, LD3_Pin);
	  HAL_Delay(500);
	  HAL_GPIO_TogglePin(LD4_GPIO_Port, LD4_Pin);
	  HAL_Delay(500);
	  HAL_GPIO_TogglePin(LD5_GPIO_Port, LD5_Pin);
	  HAL_Delay(500);*/
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 216;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 8;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_7) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.Prescaler = 0;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5.Init.Period = 4294967295;
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim5, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */

  /* USER CODE END TIM5_Init 2 */

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 10800;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 10000;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LD1_Pin|LD2_Pin|LD3_Pin|LD4_Pin
                          |LD5_Pin|LD6_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LD7_Pin|LD8_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : S2_Pin S1_Pin */
  GPIO_InitStruct.Pin = S2_Pin|S1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : LD1_Pin LD2_Pin LD3_Pin LD4_Pin
                           LD5_Pin LD6_Pin */
  GPIO_InitStruct.Pin = LD1_Pin|LD2_Pin|LD3_Pin|LD4_Pin
                          |LD5_Pin|LD6_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : LD7_Pin LD8_Pin */
  GPIO_InitStruct.Pin = LD7_Pin|LD8_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);

  HAL_NVIC_SetPriority(EXTI2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI2_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

 /* MPU Configuration */

void MPU_Config(void)
{
  MPU_Region_InitTypeDef MPU_InitStruct = {0};

  /* Disables the MPU */
  HAL_MPU_Disable();

  /** Initializes and configures the Region and the memory to be protected
  */
  MPU_InitStruct.Enable = MPU_REGION_ENABLE;
  MPU_InitStruct.Number = MPU_REGION_NUMBER0;
  MPU_InitStruct.BaseAddress = 0x0;
  MPU_InitStruct.Size = MPU_REGION_SIZE_4GB;
  MPU_InitStruct.SubRegionDisable = 0x87;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.AccessPermission = MPU_REGION_NO_ACCESS;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_SHAREABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_NOT_CACHEABLE;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);
  /* Enables the MPU */
  HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);

}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
